export const domain = 'http://localhost:3001';
